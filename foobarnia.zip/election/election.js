exports.tally = function(votes) {
  // TODO implement tally()
  return []
}
